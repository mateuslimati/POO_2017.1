#ifndef HEADER
#define HEADER

#include <iostream>
#include <vector>

using namespace std;

bool validaEmail(string email);
bool verificaTelefone(string numero);
bool verificaDuplicidade(vector<string> &telefones, string numero);

#endif // HEADER

